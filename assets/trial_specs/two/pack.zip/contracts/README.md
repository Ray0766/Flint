# contracts/ 只读副本

本目录是冻结件唯一真相的打包副本：NEVER 修改；实现 MUST 与其类型逐字一致；类型不够用 → 停止实现，按 S9 写问题单。
完整性以 MANIFEST.sha256 为准（逐文件 sha256）。
