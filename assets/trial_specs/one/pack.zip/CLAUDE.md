## S1 Charter

**目标**：方言语音标注平台：面向语音模型训练方的方言语料标注与质检服务

**非目标（NEVER 实现）**：实时热点；英文界面

**本包范围**：M1 全量任务卡（本包 S5）

## S2 Invariants

1. [MUST] 结论必有引用；数字必有出处
2. [NEVER] 修改 contracts/ 冻结件
3. [MUST] 每任务先写失败测试再实现

## S3 Contracts

**冻结件**：`contracts/models.py` + `contracts/protocols.py`——唯一真相，NEVER 修改；实现 MUST 与其类型逐字一致。

**技术选型（锁版）**：
- # 包内 lock 清单（版本钉死，S2-6）
pypi: fastapi==1.0.0
pypi: httpx==1.0.0

**目录结构**：
```
src/
  domain/
tests/
```

## S4 Decision Log

| 编号 | 决策 | 出处 |
|---|---|---|
| D1 | 金标判例 gold-C-01（C_opportunity） | assets/goldcases |

## S5 Task DAG

任务 6 张；机读真相 = 包内 tasks.json（与本表同源生成）。

| task_id | title | cycles | verify_cmd | review_gate | depends_on |
|---|---|---|---|---|---|
| T-01 | 语料采集接入（三方言区） | 1.0 | pytest tests/test_t-01.py -q | False | - |
| T-02 | 标注工作台原型 | 1.0 | pytest tests/test_t-02.py -q | False | T-01 |
| T-03 | 质检一致率度量 | 1.0 | pytest tests/test_t-03.py -q | False | T-02 |
| T-04 | 竞品对照：通用标注平台差异面 | 1.0 | pytest tests/test_t-04.py -q | False | T-01 |
| T-05 | 按量计费账务 | 1.0 | pytest tests/test_t-05.py -q | False | T-02 |
| T-06 | 交付验收包 | 1.0 | pytest tests/test_t-06.py -q | False | T-03, T-04, T-05 |

## S6 Context Manifest

- **恒装**：S2 + S3 + 当前任务卡；
- **按需**：任务卡 context_refs（下表），记法 `文件#锚点`，只装列出的章节，NEVER 整包装载；
- **预算**：单 cycle 装载 MUST ≤40000 tokens；超 → 收窄 refs 或拆任务，并在 trace 记录实际装载清单。

| task_id | context_refs |
|---|---|
| T-01 | contracts/models.py#TaskSpec, CLAUDE.md#S7 |
| T-02 | contracts/models.py#TaskSpec, CLAUDE.md#S7 |
| T-03 | contracts/models.py#TaskSpec, CLAUDE.md#S7 |
| T-04 | contracts/models.py#TaskSpec, CLAUDE.md#S7 |
| T-05 | contracts/models.py#TaskSpec, CLAUDE.md#S7 |
| T-06 | contracts/models.py#TaskSpec, CLAUDE.md#S7 |

## S7 Verification Harness

- **约定**：每任务 MUST 先写失败测试再实现（顺序不可倒）；verify_cmd exit 0 = 机器验收通过；
- **全局门**（每次合并强制）：`ruff check . && mypy --strict src && pytest -q`；
- **返工环**：verify 或 review 失败 → 按意见修改重跑；同一原因连续 2 次失败 → MUST 按 S9 升级，NEVER 第三次盲试。

| task_id | verify_cmd |
|---|---|
| T-01 | pytest tests/test_t-01.py -q |
| T-02 | pytest tests/test_t-02.py -q |
| T-03 | pytest tests/test_t-03.py -q |
| T-04 | pytest tests/test_t-04.py -q |
| T-05 | pytest tests/test_t-05.py -q |
| T-06 | pytest tests/test_t-06.py -q |

## S8 Progress Ledger（会话必死前提）

- `docs/progress.jsonl`（append-only，机器可读进度真相）——每行：
  `{"ts","task_id","event":"started|verified|review_passed|review_failed|blocked","cycles_used","note"}`
- `docs/trace/{task_id}.md`：实际装载清单（inputs 来源）+ 断点与决策日志 + 拆分/返工记录；
- **新会话启动 MUST**：读 `progress.jsonl` 末 20 行 → 定位在跑/被阻任务 → 读对应 trace → 再动手。NEVER 依赖上一会话的记忆；NEVER 重做 event=verified 之后的任务除非 review_failed。

## S9 Escalation Rules

**停下问 owner（写问题单并 blocked）**：
1. 冻结件类型/签名不够用；
2. 命中 S4 未决 Open Question 且无法绕开；
3. 新依赖 registry 校验失败、或只有付费方案；
4. context 预算或 cycle 上限无法通过拆分满足；
5. 同一原因连续 2 次 verify/review 失败；
6. 任何不可逆操作触点；

**审核 agent 检查单（review_gate 任务）**：
① 测试真实覆盖 acceptance 语义（非 assert True / 非只测 happy path）；
② 无冻结件偏离（类型、签名、判别联合逐字比对）；
③ 无禁用词；
④ trace 与 progress.jsonl 完整；
⑤ 装载未超预算；
任一不过 → `review_failed` + 意见写入 trace，任务回 started。

**人审节点（owner 本人）**：里程碑出口报告、生产部署、数据删除、付费接口开通。
